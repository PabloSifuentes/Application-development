
package br.senai.sc.edu.crudfilmes.dao;

import br.senai.sc.edu.crudfilmes.entities.Categoria;
import br.senai.sc.edu.crudfilmesMain.ConexaoDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class FilmeDAO {
    
    public Categoria buscarCategoriaPorNome(String nome) throws SQLException {
        String sql = "SELECT * FROM Filme WHERE nome = ?";
        try (Connection conn = ConexaoDB.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Categoria(rs.getInt("id"), rs.getString("nome"));
            }
        }
        return null;
    }
    
    public void atualizarFilme(FilmeDAO filme) throws SQLException {
        String sql = "UPDATE Filme SET nome = ? WHERE id = ?";
        try (Connection conn = ConexaoDB.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, filme.getNome);
            stmt.setInt(2, filme.getId());
            stmt.executeUpdate();
        }
    }
    
}
