package edu.senai.br.projeto.jdbc;

import edu.senai.br.projeto.jdbc.DAO.CategoriaDAO;
import edu.senai.br.projeto.jdbc.DAO.FilmeDAO;
import edu.senai.br.projetojdbc.entities.Categoria;
import java.sql.SQLException;

/**
 *
 * @author pablo_sifuentes
 */
public class Projetojdbc {

    public static void main(String[] args) {

        try {
            // Instancia os DAOs
            CategoriaDAO categoriaDAO = new CategoriaDAO();
            FilmeDAO filmeDAO = new FilmeDAO();

            // Cria categorias
            Categoria cat1 = new Categoria(0, "Ação");
            Categoria cat2 = new Categoria(0, "Comédia");
            Categoria cat3 = new Categoria(0, "Drama");
            Categoria cat4 = new Categoria(0, "Sci-Fi");

            // Insere as categorias usando o objeto categoriaDAO
            categoriaDAO.inserirCategoria(cat1);
            categoriaDAO.inserirCategoria(cat2);
            categoriaDAO.inserirCategoria(cat3);
            categoriaDAO.inserirCategoria(cat4);
            
             (categoriaDAO.listarCategorias().stream()).forEach(System.out::println);
             
        } catch (SQLException e) {
            System.out.println("\nAlgo errado aconteceu com a manipulação do DB!");
            e.printStackTrace(); // Isso vai te ajudar a ver o erro detalhado no console
        }
        
       
        
        
        
    
    }
}
