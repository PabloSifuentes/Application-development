
package edu.senai.br.projeto.jdbc;

import java.sql.Connection;
import edu.senai.br.projeto.jdbc.ConexaoDB;

/**
 *
 * @author pablo_sifuentes
 */
import java.sql.SQLException;
public class TestConexao {
       public static void main(String[] args) {
        Connection conexao = null;
        try {
            // Obtém a conexão com o banco de dados
            conexao = ConexaoDB.getConnection();
            System.out.println("Conexão ao banco de dados bem sucedida");
            conexao.close();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar ao banco de dados: " + e.getMessage());
        }  
        
        
    }
}
    
 
