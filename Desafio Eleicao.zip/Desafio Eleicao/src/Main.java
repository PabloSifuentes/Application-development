import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

    GerenciamentoEleicao eleicao = new GerenciamentoEleicao();
    Scanner entradaDeVoto = new Scanner(System.in);
    int eleitores = 50;

    // Loop para coletar os votos de 50 eleitores
        for(int i = 0; i < eleitores; i++) {
        System.out.println("Eleitor " + (i + 1) + ":");

        // Informar turma
        System.out.println("Informe a sua turma (1 - Primeiro, 2 - Segundo, 3 - Terceiro ano): ");
        int turma = entradaDeVoto.nextInt();
        while (turma < 1 || turma > 3) {
            System.out.println("Turma inválida. Informe a turma correta (1, 2 ou 3):");
            turma = entradaDeVoto.nextInt();
        }

        // Informar voto
        System.out.println("Informe o número da chapa que deseja votar: ");
            System.out.println("" +
                    "[1] - Ana \n" +
                    "[2] - Pedro \n" +
                    "[3] - Rita \n" +
                    "[4] - Alfredo \n" +
                    "[5] - Regina \n" +
                    "[6] - Ricardo \n" +
                    "[0] - Voto Nulo \n" +
                    "[10] - Voto Branco \n");
        int voto = entradaDeVoto.nextInt();
        while (voto != 0 && voto != 10 && (voto < 1 || voto > 6)) {
            System.out.println("Voto inválido. Informe o número correto. ");
        voto = entradaDeVoto.nextInt();
        }

        // Contabilizar voto
        eleicao.votar(voto, turma);
    }
    // Mostrar os resultados ao final
        eleicao.mostrarResultados();
        entradaDeVoto.close();
    }
}